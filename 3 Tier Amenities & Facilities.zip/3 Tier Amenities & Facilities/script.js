document.addEventListener("DOMContentLoaded", function() {
    let tabs = document.querySelectorAll('.nav-link');
    let contents = document.querySelectorAll('.tab-pane');

    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');

            // Hide all tab contents
            contents.forEach(c => {
                c.classList.remove('show', 'active');
            });

            // Show the clicked tab content
            let target = document.querySelector(this.dataset.bsTarget);
            target.classList.add('show', 'active');
        });
    });
});
